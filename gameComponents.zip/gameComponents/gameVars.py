from random import randint

choices = ["rock", "paper", "scissors"]

player = False
computer = choices[randint(0, 2)]

playerLives = 3
computerLives = 3